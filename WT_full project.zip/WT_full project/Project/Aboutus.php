<?php include('Controller/navbar.php');?>
 


 <!DOCTYPE html>
 <html>
 <head>
 	<title></title>
 	<style>
 		p{
 			font-style: float:right;

 		}
 		footer {
   			padding: 60px;
  			background-color: #00A79D;
  			color: white;
  			height: 100%;
  			width: 100%;
}
img {
	align-items: center;
}
h2 {
	text-align: center;
}
 	</style>
 </head>
 <body>
 	<h2>About Us:</h2>
 	<p><h3>Vehicle Rental Application is created for making your life more easier. You will find your desired  
vehicle here. And the best part is you can take those vehicles as long as you want. 
We have an huge collection of latest models of SUVs, Sedan and exotic motorbikes. 
So, choose your suitable one and enjoy our service.</h3></p>
 	
 	<p> </p>
 	<footer>
 		<?php include('footer.php');?>
	</footer>
 </body>
 </html>