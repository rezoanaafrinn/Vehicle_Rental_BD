<?php include('Controller/navbar.php');?>
 


 <!DOCTYPE html>
 <html>
 <head>
 	<title></title>
 	<style>
 		p{
 			font-style: float:right;

 		}
 		footer {
   			padding: 60px;
  			background-color: #00A79D;
  			color: white;
  			height: 100%;
  			width: 100%;
}
img {
	align-items: center;
}
h2 {
	text-align: center;
}
 	</style>
 </head>
 <body>
 	<h2>Contact Us:</h2>
 	<h3>Website: VehicleRental.com.bd</h3><br>
 	<h3>Hotline: 0123456578</h3><br>
 	<h3>Location: House # 06, Road # 137, Block # SE(D), Gulshan-1, Dhaka, Bangladesh.</h3><br>
 	<h3>Facebook: facebook.com/vehicleRental</h3><br>

 	<p> </p>
 	<footer>
 		<?php include('footer.php');?>
</footer>
 </body>
 </html>