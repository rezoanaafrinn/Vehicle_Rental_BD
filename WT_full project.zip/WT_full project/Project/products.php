<!DOCTYPE html>
<html>
<head>
	<meta name="viewport" content="width=device-width,initial-scale=1"/>
	<title>products</title>

</head>
<body>
	<header>
		<h1>Products</h1>
		<button id="btn">Fetch Info for products</button>
	</header>
	<div id="animal-info"></div>
	<script src="main.js"></script>
</body>
</html>