<?php
include("Nav.php");

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title></title>
<link rel="stylesheet" href="css/profile1.css">
</head>
<body>
<div class="main">
   <div class="element">

    <form action="user_profile.php" method="post" enctype="multipart/form-data">

            <?php
				session_start();
				include 'database.php';
				$Id= $_SESSION["Id"];
				$sql=mysqli_query($conn,"SELECT * FROM userlogin where Id='$Id' ");
				$row  = mysqli_fetch_array($sql);
            ?>
    <h2>About   <?php echo $_SESSION["Name"] ?> </h2> <br>
            <img class="pic" src="upload/<?php echo $row['File'] ?>" height="120" width="120"/> <br>

        <p><b> Name : </b> <?php echo $_SESSION["Name"] ?></p> <br>

        <p><b>Email: </b> <?php echo $_SESSION["Email"] ?></p><br>
        

         </form>

         </div>
         

   </div>
</body>
</html>
